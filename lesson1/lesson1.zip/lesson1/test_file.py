first_part = 'hello '
number = 6
second_part = 'world'

print(first_part + str(6) + ' '+ second_part)
print(5 ** 3)
print(pow(5, 3))